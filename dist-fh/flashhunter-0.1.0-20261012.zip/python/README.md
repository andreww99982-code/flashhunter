# Python: контур управления FlashHunter

Всё, что важно быстро менять и читать человеком: риск, PnL, API, панель, аудит,
бэктест и уведомления. Python 3.12, FastAPI, SQLAlchemy 2 (async), pydantic-settings.

## Состав пакета

```
flashhunter/
├── api/            # FastAPI: роутеры (12 модулей), WebSocket, метрики, авторизация
├── strategies/     # 7 стратегий + математика AMM (V2/V3/stable) + сервис-оркестратор
├── risk/           # Риск-движок: лимиты, экспозиция, kill-switch (право вето)
├── execution/      # Симулятор, сборщик bundle, клиент релеев, исполнитель
├── backtest/       # Движок бэктеста: профили рынка, grid-search, отчёты JSON/CSV
├── alerting/       # Telegram, Discord, универсальный webhook, журнал
├── pnl/            # PnL-трекер: агрегаты по периодам, equity-кривая
├── deployer/       # Деплой и верификация контрактов через Foundry
├── market/         # Источник данных: мок-рынок (для локального запуска) и реальный
├── db/             # 17 моделей SQLAlchemy, сессии, идемпотентный сид демо-данных
└── config/         # Настройки (pydantic-settings) и шифрование секретов

tests/              # 130 тестов: db, risk, math, strategies, execution, api, alerting, backtest
pyproject.toml      # зависимости, ruff (line-length 110), mypy strict, pytest (asyncio_mode=auto)
pytest.ini          # testpaths=tests
```

## Запуск

```bash
pip install -e ".[dev]"          # зависимости разработки
pytest -q                        # 130 тестов
uvicorn flashhunter.api.app:app --host 0.0.0.0 --port 8000   # API + панель + оркестратор
```

Через корневой Makefile: `make install`, `make test`, `make dev`, `make lint`.

## Переменные окружения (главные)

| Переменная | Смысл |
|-----------|-------|
| `FLASHHUNTER_ENV` | `dev` \| `staging` \| `prod` — режим строгости настроек |
| `FLASHHUNTER_DRY_RUN` | `true` — сделки симулируются, но не отправляются |
| `MOCK_MARKET_DATA` | `true` — мок-рынок: старт без RPC-ключей |
| `FLASHHUNTER_DB_MODE` | `sqlite` \| `postgres` |
| `SQLITE_PATH` | Путь к файлу SQLite (в compose — `/data/flashhunter.db`) |
| `JWT_SECRET`, `ADMIN_DEFAULT_USER/PASSWORD` | Авторизация панели и первый вход |
| `RISK_*` | Дневной и часовой лимиты убытка, экспозиция, потеря соединения |
| `EXEC_*` | Минимальная прибыль, потолок газа, проскальзывание, таймаут симуляции |
| `ALERT_*` | Telegram-токен/чат, Discord-webhook, произвольный webhook |

Полный список — `../.env.example` (более 80 параметров с комментариями).

## Тесты

```bash
pytest -q                       # всё (130 тестов, ~60 секунд)
pytest tests/risk -q            # только риск-движок
pytest tests/api -q             # только API
pytest -k "kill_switch" -q      # по имени
```

Фикстуры (`tests/conftest.py`) выставляют переменные окружения **до** импорта
пакета, создают БД (`init_models` + `seed_all`) и поднимают `TestClient`
с авторизованной сессией admin.

## Соглашения по коду

* Комментарии: бизнес-логика — по-русски, низкоуровневые детали — по-английски.
* Линт: `ruff` с набором правил E/F/W/I/N/UP/B/C4/SIM/ASYNC/S/RET/PTH/TID.
* Типы: `mypy --strict` для `flashhunter/`, тесты исключены.
* Проверка перед коммитом: `make lint && make test`.
