"""Executor: путь сделки от найденной возможности до записи в БД.

Порядок: risk.check -> reserve exposure -> simulate -> bundle build -> relay submit
-> persist trade -> risk.record_outcome. Каждый шаг логируется метрикой латентности,
итоговая задержка «блок -> bundle отправлен» уходит в risk-engine (контроль p99).
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from decimal import Decimal
from typing import Any

from sqlalchemy.ext.asyncio import AsyncSession

from flashhunter.db.models import Opportunity as OpportunityRow
from flashhunter.db.models import OpportunityStatus, Trade, TradeStatus
from flashhunter.execution.bundle_builder import BundleBuilder, BundlePlan
from flashhunter.execution.relays import RelayClient, RelayResponse
from flashhunter.execution.simulator import LocalSimulator, SimulationResult
from flashhunter.market.snapshot import MarketSnapshot
from flashhunter.risk.engine import RiskEngine, TradeOutcome
from flashhunter.strategies.base import Opportunity

log = logging.getLogger(__name__)


@dataclass(slots=True)
class ExecutionResult:
    """Итог обработки одной возможности."""

    uid: str
    accepted: bool
    status: str
    net_profit_usd: Decimal
    bundle_hash: str = ""
    relay: str = ""
    reason: str = ""
    latency_ms: float = 0.0
    simulation: SimulationResult | None = None
    plan: BundlePlan | None = None
    trade_id: int | None = None
    relay_responses: list[RelayResponse] = field(default_factory=list)

    def as_dict(self) -> dict[str, Any]:
        """Плоское представление для WS/логов."""
        return {
            "uid": self.uid,
            "accepted": self.accepted,
            "status": self.status,
            "net_profit_usd": float(self.net_profit_usd),
            "bundle_hash": self.bundle_hash,
            "relay": self.relay,
            "reason": self.reason,
            "latency_ms": round(self.latency_ms, 2),
        }


class Executor:
    """Исполнитель сделок с полным контролем риска."""

    def __init__(
        self,
        risk: RiskEngine,
        *,
        simulator: LocalSimulator | None = None,
        builder: BundleBuilder | None = None,
        relays: RelayClient | None = None,
    ) -> None:
        self.risk = risk
        self.simulator = simulator or LocalSimulator(slippage_tolerance_bps=risk.slippage_ceiling_bps)
        self.builder = builder or BundleBuilder()
        self.relays = relays or RelayClient()

    # ------------------------------------------------------------------ #
    async def execute(
        self, opp: Opportunity, snapshot: MarketSnapshot, session: AsyncSession
    ) -> ExecutionResult:
        """Полный цикл исполнения одной возможности."""
        started = time.perf_counter()
        size_usd = opp.size_usd
        net = opp.net_profit_usd

        # 1. Риск-контроль ------------------------------------------------
        decision = self.risk.check(
            chain_id=opp.chain_id,
            token_in=opp.token_in,
            size_usd=size_usd,
            net_profit_usd=net,
            base_fee_gwei=snapshot.base_fee_gwei,
            slippage_bps=self.risk.slippage_ceiling_bps,
            protocol=str(opp.meta.get("protocol", "")),
        )
        if not decision.allow:
            latency = (time.perf_counter() - started) * 1000
            log.info("opportunity %s rejected by risk: %s", opp.uid, decision.reason)
            return ExecutionResult(opp.uid, False, "rejected", net, reason=decision.reason,
                                   latency_ms=latency)

        self.risk.reserve_exposure(opp.chain_id, opp.token_in, size_usd)

        # 2. Симуляция ----------------------------------------------------
        simulation = await self.simulator.simulate(opp, snapshot)
        if not simulation.success:
            latency = (time.perf_counter() - started) * 1000
            await self._persist_trade(session, opp, TradeStatus.reverted, Decimal("0"),
                                      revert_reason=simulation.revert_reason, latency_ms=latency)
            self.risk.record_outcome(
                TradeOutcome(time.time(), opp.chain_id, Decimal("0"), "reverted", latency,
                             size_usd=size_usd, token=opp.token_in)
            )
            return ExecutionResult(opp.uid, False, "reverted", Decimal("0"),
                                   reason=simulation.revert_reason, latency_ms=latency,
                                   simulation=simulation)

        # 3. Сборка bundle ------------------------------------------------
        plan = self.builder.build(opp, snapshot, gas_used=simulation.gas_used,
                                  sender=str(opp.meta.get("sender", "")))

        # 4. Отправка в релеи (в dry-run — смоделированный ответ) ---------
        responses = await self.relays.submit_all(plan) if not self.risk.dry_run else []
        accepted = [r for r in responses if r.accepted]
        relay = accepted[0].relay if accepted else ("dry_run" if self.risk.dry_run else "")

        status = TradeStatus.success if (self.risk.dry_run or accepted) else TradeStatus.dropped
        reason = "dry_run" if self.risk.dry_run else ("" if accepted else "no_relay_accepted")
        profit = net if self.risk.dry_run else (net if accepted else Decimal("0"))

        # 5. Персистентность ---------------------------------------------
        trade_id = await self._persist_trade(
            session, opp, status, profit, bundle_hash=plan.bundle_hash, relay=relay,
            revert_reason=reason, latency_ms=(time.perf_counter() - started) * 1000,
            gas_used=simulation.gas_used, extra={"simulation": simulation.as_dict()},
        )

        latency_ms = (time.perf_counter() - started) * 1000
        self.risk.record_outcome(
            TradeOutcome(time.time(), opp.chain_id, profit, status.value, latency_ms,
                         size_usd=size_usd, token=opp.token_in)
        )
        self.risk.record_latency(latency_ms)

        log.info(
            "executed %s via %s: status=%s profit=$%.2f latency=%.1fms",
            opp.uid, relay or "n/a", status.value, float(profit), latency_ms,
        )
        return ExecutionResult(
            uid=opp.uid,
            accepted=status == TradeStatus.success,
            status=status.value,
            net_profit_usd=profit,
            bundle_hash=plan.bundle_hash,
            relay=relay,
            reason=reason,
            latency_ms=latency_ms,
            simulation=simulation,
            plan=plan,
            trade_id=trade_id,
            relay_responses=responses,
        )

    # ------------------------------------------------------------------ #
    async def _persist_trade(
        self,
        session: AsyncSession,
        opp: Opportunity,
        status: TradeStatus,
        profit: Decimal,
        *,
        bundle_hash: str = "",
        relay: str = "",
        revert_reason: str = "",
        latency_ms: float = 0.0,
        gas_used: int = 0,
        extra: dict[str, Any] | None = None,
    ) -> int:
        """Пишет сделку в БД (trades) и возвращает её id."""
        trade = Trade(
            opportunity_id=int(opp.meta.get("db_id", 0)) or None,
            chain_id=opp.chain_id,
            strategy=opp.strategy,
            tx_hash=None if self.risk.dry_run else "0x" + bundle_hash[-64:].lstrip("0x"),
            bundle_hash=bundle_hash,
            relay=relay or None,
            block_number=opp.block_number,
            gas_used=gas_used,
            gas_price_gwei=float(self.builder.settings.exec_priority_fee_gwei),
            priority_fee_gwei=float(self.builder.settings.exec_priority_fee_gwei),
            actual_profit_usd=profit,
            status=status,
            revert_reason=revert_reason or None,
            latency_ms=int(latency_ms),
        )
        session.add(trade)
        await session.flush()
        _ = extra
        return trade.id

    # ------------------------------------------------------------------ #
    async def persist_opportunity(
        self, session: AsyncSession, opp: Opportunity, status: OpportunityStatus
    ) -> int:
        """Пишет найденную возможность в БД (opportunities) и возвращает её id."""
        row = OpportunityRow(
            chain_id=opp.chain_id,
            strategy=opp.strategy,
            token_in=opp.token_in,
            token_out=opp.token_out,
            dex_buy=opp.dex_buy,
            dex_sell=opp.dex_sell,
            path={
                "pools": opp.pools,
                "tokens": opp.tokens,
                "kind": opp.kind,
                "route": opp.meta.get("route", ""),
                "uid": opp.uid,
            },
            size_usd=opp.size_usd,
            gross_profit_usd=opp.profit_usd,
            gas_usd=opp.gas_usd,
            flash_fee_usd=opp.flash_fee_usd,
            net_profit_usd=opp.net_profit_usd,
            roi_pct=opp.roi_pct,
            confidence=opp.confidence,
            status=status,
            block_number=opp.block_number,
        )
        session.add(row)
        await session.flush()
        opp.meta["db_id"] = str(row.id)
        return row.id
