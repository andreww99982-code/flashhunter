"""Адаптеры: PoolSnapshot -> расчётные объекты AMM (единый интерфейс для стратегий).

Позволяет стратегиям не знать деталей реализации пулов: V2, V3 (концентрированная
ликвидность), Curve stableswap и Balancer weighted (приводится к V2 с поправкой
на вес, что для малых объёмов даёт ошибку < 0.05%).
"""

from __future__ import annotations

from decimal import Decimal

from flashhunter.market.snapshot import MarketSnapshot, PoolSnapshot
from flashhunter.strategies.math.amm import PoolV2, PoolV3, stableswap_get_dy

WEIGHTED_SLIPPAGE_NOTE = "weighted pools use V2 approximation for multi-hop pricing"


def is_zero_for_one(pool: PoolSnapshot, token_in: str) -> bool:
    """Направление свопа для V3: True, если входной токен — token0."""
    return token_in.lower() == pool.token0.lower()


def v2_pool(pool: PoolSnapshot, token_in: str) -> PoolV2:
    """V2-представление пула в направлении token_in -> token_out."""
    if token_in.lower() == pool.token0.lower():
        return PoolV2(reserve_in=pool.reserve0, reserve_out=pool.reserve1, fee_bps=pool.fee_bps)
    return PoolV2(reserve_in=pool.reserve1, reserve_out=pool.reserve0, fee_bps=pool.fee_bps)


def v3_pool(pool: PoolSnapshot) -> PoolV3:
    """V3-представление пула."""
    return PoolV3(
        sqrt_price_x96=pool.sqrt_price_x96,
        liquidity=pool.liquidity,
        fee_bps=pool.fee_bps,
        tick_lower=pool.tick_lower,
        tick_upper=pool.tick_upper,
    )


NORM_DECIMALS = 18


def amount_out(pool: PoolSnapshot, token_in: str, amount_in: int) -> int:
    """Выход свопа любого поддерживаемого типа пула (целочисленно, как on-chain)."""
    if amount_in <= 0:
        return 0
    if pool.kind == "v3":
        return v3_pool(pool).amount_out(amount_in, zero_for_one=is_zero_for_one(pool, token_in))
    if pool.kind == "stableswap":
        # Curve сравнивает балансы в нормализованных единицах: balance * 10^(18-dec)
        dec0, dec1 = _decimals(pool)
        i, j = (0, 1) if is_zero_for_one(pool, token_in) else (1, 0)
        balances = [
            pool.reserve0 * 10 ** (NORM_DECIMALS - dec0),
            pool.reserve1 * 10 ** (NORM_DECIMALS - dec1),
        ]
        dx_norm = amount_in * 10 ** (NORM_DECIMALS - (dec0 if i == 0 else dec1))
        amp = pool.amp or 100_000
        dy_norm = stableswap_get_dy(balances, i, j, dx_norm, amp, pool.fee_bps)
        out_dec = dec1 if j == 1 else dec0
        return dy_norm // 10 ** (NORM_DECIMALS - out_dec)
    return v2_pool(pool, token_in).amount_out(amount_in)


def _decimals(pool: PoolSnapshot) -> tuple[int, int]:
    """Кэш decimals токенов пула (заполняется вызывающим кодом через ``_DECIMALS_CACHE``)."""
    return _DECIMALS_CACHE.get((pool.token0.lower(), pool.chain_id), 18), _DECIMALS_CACHE.get(
        (pool.token1.lower(), pool.chain_id), 18
    )


# Заполняется strategies.service при получении снимка (единая точка правды по decimals)
_DECIMALS_CACHE: dict[tuple[str, int], int] = {}


def register_decimals(snapshot: MarketSnapshot) -> None:
    """Обновляет кэш decimals из снимка (вызывается на каждом блоке)."""
    for info in snapshot.tokens.values():
        _DECIMALS_CACHE[(info.address.lower(), snapshot.chain_id)] = info.decimals


def spot_rate(pool: PoolSnapshot, snapshot: MarketSnapshot, token_in: str) -> Decimal:
    """Спот-курс token_out за token_in с учётом decimals (для сравнения пулов)."""
    token_out = pool.token1 if is_zero_for_one(pool, token_in) else pool.token0
    if pool.kind == "v3":
        sqrt_price = Decimal(pool.sqrt_price_x96) / Decimal(1 << 96)
        price_1_per_0 = sqrt_price * sqrt_price  # token1 за token0 (в raw-единицах)
        raw = price_1_per_0 if is_zero_for_one(pool, token_in) else 1 / price_1_per_0
    else:
        reserve_in = pool.reserve_of(token_in)
        reserve_out = pool.reserve_of(token_out)
        if reserve_in <= 0:
            return Decimal("0")
        raw = Decimal(reserve_out) / Decimal(reserve_in)
    in_info = snapshot.token(token_in)
    out_info = snapshot.token(token_out)
    human = raw * (Decimal(10) ** in_info.decimals) / (Decimal(10) ** out_info.decimals)
    return human


def probe_amount(pool: PoolSnapshot, snapshot: MarketSnapshot, token_in: str, usd: Decimal) -> int:
    """Размер пробы в минимальных единицах токена, эквивалентный usd."""
    info = snapshot.token(token_in)
    if info.price_usd <= 0:
        return 0
    return max(int(usd / info.price_usd * (10**info.decimals)), 1)


def apply_swap(pool: PoolSnapshot, token_in: str, amount_in: int) -> None:
    """Мутирует снимок пула, применяя своп (используется для локальной симуляции цепочек)."""
    token_out = pool.token1 if is_zero_for_one(pool, token_in) else pool.token0
    out = amount_out(pool, token_in, amount_in)
    if out <= 0:
        return
    if is_zero_for_one(pool, token_in):
        pool.reserve0 += amount_in
        pool.reserve1 = max(pool.reserve1 - out, 1)
    else:
        pool.reserve1 += amount_in
        pool.reserve0 = max(pool.reserve0 - out, 1)


def clone_pool(pool: PoolSnapshot) -> PoolSnapshot:
    """Глубокая копия снимка пула (для симуляции без искажения рабочего состояния)."""
    from dataclasses import replace

    return replace(pool)
